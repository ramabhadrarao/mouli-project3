const express = require('express');
const router = express.Router();
const routeCalculator = require('../services/routeCalculator');
const safetyEvaluator = require('../services/safetyEvaluator');
const axios = require('axios');

// Function to calculate safety score
function calculateSafetyScore(route) {
  // Sample safety scoring logic
  const factors = {
    schoolZoneRisk: 0.2,
    residentialExposure: 0.2,
    roadQualityRisk: 0.15,
    weatherRisk: 0.15,
    trafficCongestionRisk: 0.15,
    emergencyAccess: 0.15
  };

  // Generate random scores for demonstration
  const safetyMetrics = {};
  Object.keys(factors).forEach(key => {
    safetyMetrics[key] = {
      score: Math.floor(Math.random() * 100),
      weight: factors[key]
    };
  });

  // Calculate overall safety score
  const overallScore = Object.entries(safetyMetrics).reduce((total, [key, metric]) => {
    return total + (metric.score * metric.weight);
  }, 0) / Object.values(factors).reduce((a, b) => a + b, 0);

  return {
    safetyMetrics,
    overallScore
  };
}

// Calculate routes
router.post('/calculate-routes', async (req, res) => {
  try {
    const { 
      origin, 
      destination, 
      originLat, 
      originLng, 
      destLat, 
      destLng,
      tankerType,
      hazmatClass,
      avoidHighways,
      avoidTolls
    } = req.body;

    // Validate inputs
    if ((!origin && (!originLat || !originLng)) || 
        (!destination && (!destLat || !destLng))) {
      return res.status(400).json({ 
        success: false, 
        message: 'Origin and destination are required' 
      });
    }

    // Prepare Google Maps Directions API request
    const directionsUrl = 'https://maps.googleapis.com/maps/api/directions/json';
    const apiKey = process.env.GOOGLE_MAPS_API_KEY;

    // Prepare parameters
    const params = {
      origin: origin || `${originLat},${originLng}`,
      destination: destination || `${destLat},${destLng}`,
      key: apiKey,
      alternatives: true // Request multiple routes
    };

    // Add routing preferences
    const options = [];
    if (avoidHighways) options.push('highways');
    if (avoidTolls) options.push('tolls');
    if (options.length > 0) {
      params.avoid = options.join('|');
    }

    // Make request to Google Directions API
    const response = await axios.get(directionsUrl, { params });

    // Process routes
    const routes = response.data.routes.map((route, index) => {
      // Calculate safety metrics
      const { safetyMetrics, overallScore } = calculateSafetyScore(route);

      // Extract route details
      return {
        routeId: `route-${Date.now()}-${index}`,
        summary: route.summary || `Route ${index + 1}`,
        distance: route.legs[0].distance.value, // meters
        duration: route.legs[0].duration.value, // seconds
        polyline: route.overview_polyline.points,
        safetyScore: overallScore,
        isSafest: index === 0, // First route considered safest
        color: index === 0 ? '#4CAF50' : '#3498db',
        justification: 'Route minimizes exposure to school zones and residential areas.',
        bounds: route.bounds,
        legs: route.legs,
        safetyMetrics
      };
    });

    res.json({
      success: true,
      routes
    });
  } catch (error) {
    console.error('Route calculation error:', error.response ? error.response.data : error.message);
    res.status(500).json({ 
      success: false, 
      message: error.response?.data?.error_message || error.message || 'Failed to calculate routes' 
    });
  }
});

// Get detailed metrics for a specific route
router.get('/route-metrics/:routeId', async (req, res) => {
  try {
    const { routeId } = req.params;
    
    // Generate sample metrics
    const metrics = {
      basicMetrics: {
        distance: '16 km',
        duration: '65 minutes',
        trafficDuration: '85 minutes',
        fuelConsumption: '39 liters',
        co2Emissions: '109 kg',
        averageSpeed: '66 km/h'
      },
      safetyPercentages: {
        schoolZoneRisk: 80,
        residentialExposure: 75,
        roadQualityRisk: 85,
        weatherRisk: 70,
        trafficCongestionRisk: 75,
        emergencyAccess: 60
      },
      restrictions: {
        hazmat: [
          { 
            location: 'Bridge', 
            description: 'No flammable liquids at approximately 40% of route' 
          }
        ],
        speed: [
          { 
            location: 'School zone', 
            limit: '30 km/h at approximately 30% of route' 
          }
        ],
        weight: []
      }
    };
    
    res.json({
      success: true,
      metrics
    });
  } catch (error) {
    console.error('Error fetching route metrics:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve route metrics',
      error: error.message
    });
  }
});
// Get hazmat restrictions for an area
router.get('/hazmat-restrictions', async (req, res) => {
  try {
    const { bounds } = req.query;
    const restrictions = await routeCalculator.getHazmatRestrictions(bounds);
    
    res.json({
      success: true,
      restrictions
    });
  } catch (error) {
    console.error('Error fetching hazmat restrictions:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve hazmat restrictions',
      error: error.message
    });
  }
});

// Get school zones for an area
router.get('/school-zones', async (req, res) => {
  try {
    const { bounds } = req.query;
    const schoolZones = await routeCalculator.getSchoolZones(bounds);
    
    res.json({
      success: true,
      schoolZones
    });
  } catch (error) {
    console.error('Error fetching school zones:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve school zones',
      error: error.message
    });
  }
});

module.exports = router;
