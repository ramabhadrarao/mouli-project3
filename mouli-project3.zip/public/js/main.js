/**
 * Oil Tanker Safety Routing - Main Client-Side JavaScript
 */


// Global variables
window.map = window.map || null;
window.directionsService = window.directionsService || null;
window.directionsRenderer = window.directionsRenderer || null;
window.markerOrigin = window.markerOrigin || null;
window.markerDestination = window.markerDestination || null;
window.activeSelection = window.activeSelection || null;
window.routePolylines = window.routePolylines || [];
window.currentRoutes = window.currentRoutes || [];

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  // Set up event listeners
  setupEventListeners();
});

/**
 * Initialize Google Maps
 */
window.initMap = function() {
  // Your existing map initialization code
  if (document.getElementById('map')) {
    window.map = new google.maps.Map(document.getElementById('map'), {
      center: { lat: 28.6139, lng: 77.2090 },
      zoom: 10,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });
    
    // Other initialization logic
    if (typeof setupAutocomplete === 'function') setupAutocomplete();
    if (typeof setupMapPointSelection === 'function') setupMapPointSelection();
    if (typeof loadRestrictedZones === 'function') loadRestrictedZones();
  }
};

/**
 * Create a marker with support for AdvancedMarkerElement
 * @param {Object} position - Marker position
 * @param {Object} map - Google Maps instance
 * @param {string} title - Marker title
 * @param {string} content - Optional marker content
 * @returns {Object} - Marker instance
 */
function createMarker(position, map, title, content = null) {
  try {
    // Check if AdvancedMarkerElement is available
    if (google.maps.marker && google.maps.marker.AdvancedMarkerElement) {
      const pinBackground = new google.maps.marker.PinElement({
        background: '#4285f4',
        borderColor: '#4285f4',
        glyphColor: 'white'
      });

      return new google.maps.marker.AdvancedMarkerElement({
        position: position,
        map: map,
        title: title,
        content: pinBackground.element
      });
    } else {
      // Fallback to traditional marker
      return new google.maps.Marker({
        position: position,
        map: map,
        title: title
      });
    }
  } catch (error) {
    console.error('Error creating marker:', error);
    return new google.maps.Marker({
      position: position,
      map: map,
      title: title
    });
  }
}

/**
 * Set up map point selection with Advanced Marker support
 */
// Improved Map Point Selection Script
// Improved Map Point Selection and Geocoding

// Improved Map Point Selection and Geocoding
// Global variables for markers and map
window.originMarker = null;
window.destinationMarker = null;
window.map = null;

// Initialize map and point selection
function initMapPointSelection() {
  const mapElement = document.getElementById('map');
  const originInput = document.getElementById('origin-input');
  const destinationInput = document.getElementById('destination-input');
  const pickOriginBtn = document.getElementById('pick-origin');
  const pickDestinationBtn = document.getElementById('pick-destination');

  // Validate elements exist
  if (!mapElement || !originInput || !destinationInput || 
      !pickOriginBtn || !pickDestinationBtn) {
    console.error('Required map elements not found');
    return;
  }

  // Initialize map if not already done
  if (!window.map) {
    window.map = new google.maps.Map(mapElement, {
      center: { lat: 40.7128, lng: -74.0060 }, // Default to New York
      zoom: 10,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });
  }

  // Geocoder for address lookup
  const geocoder = new google.maps.Geocoder();

  // Function to create or update marker
  function createMarker(location, type) {
    // Remove existing marker
    const existingMarker = type === 'origin' ? window.originMarker : window.destinationMarker;
    if (existingMarker) {
      existingMarker.setMap(null);
    }

    // Create new marker
    const marker = new google.maps.Marker({
      position: location,
      map: window.map,
      title: type === 'origin' ? 'Origin Point' : 'Destination Point',
      icon: type === 'origin' 
        ? 'http://maps.google.com/mapfiles/ms/icons/green-dot.png'
        : 'http://maps.google.com/mapfiles/ms/icons/red-dot.png'
    });

    // Store marker globally
    if (type === 'origin') {
      window.originMarker = marker;
    } else {
      window.destinationMarker = marker;
    }

    // Center map on marker
    window.map.setCenter(location);
    window.map.setZoom(10);

    return marker;
  }

  // Handle map click for point selection
  let currentSelectionMode = null;
  window.map.addListener('click', function(event) {
    if (!currentSelectionMode) return;

    const clickedLocation = event.latLng;

    // Perform reverse geocoding
    geocoder.geocode({ location: clickedLocation }, (results, status) => {
      if (status === 'OK' && results[0]) {
        // Create marker
        const marker = createMarker(clickedLocation, currentSelectionMode);

        // Update input field with full address
        const input = currentSelectionMode === 'origin' ? originInput : destinationInput;
        input.value = results[0].formatted_address;

        // Store geocoded location data
        if (currentSelectionMode === 'origin') {
          window.originAddress = results[0].formatted_address;
          window.originLocation = {
            lat: clickedLocation.lat(),
            lng: clickedLocation.lng()
          };
        } else {
          window.destinationAddress = results[0].formatted_address;
          window.destinationLocation = {
            lat: clickedLocation.lat(),
            lng: clickedLocation.lng()
          };
        }
      } else {
        console.error('Geocoding failed:', status);
        
        // Fallback to lat/lng if geocoding fails
        const input = currentSelectionMode === 'origin' ? originInput : destinationInput;
        input.value = `${clickedLocation.lat()}, ${clickedLocation.lng()}`;
        
        // Still create marker
        createMarker(clickedLocation, currentSelectionMode);
      }

      // Reset selection mode
      currentSelectionMode = null;
      mapElement.style.cursor = 'default';
    });
  });

  // Set up click listeners for select buttons
  pickOriginBtn.addEventListener('click', () => {
    currentSelectionMode = 'origin';
    mapElement.style.cursor = 'crosshair';
  });

  pickDestinationBtn.addEventListener('click', () => {
    currentSelectionMode = 'destination';
    mapElement.style.cursor = 'crosshair';
  });

  // Set up autocomplete for input fields
  const originAutocomplete = new google.maps.places.Autocomplete(originInput, {
    types: ['geocode']
  });
  const destinationAutocomplete = new google.maps.places.Autocomplete(destinationInput, {
    types: ['geocode']
  });

  // Handle place selection from autocomplete
  originAutocomplete.addListener('place_changed', () => {
    const place = originAutocomplete.getPlace();
    if (place.geometry) {
      // Create marker specifically for origin
      const marker = createMarker(place.geometry.location, 'origin');
      
      // Ensure input shows full address
      originInput.value = place.formatted_address || place.name;

      // Store geocoded location data
      window.originAddress = place.formatted_address || place.name;
      window.originLocation = {
        lat: place.geometry.location.lat(),
        lng: place.geometry.location.lng()
      };
    }
  });

  // Unique place changed listeners for destination
  destinationAutocomplete.addListener('place_changed', () => {
    const place = destinationAutocomplete.getPlace();
    if (place.geometry) {
      // Create marker specifically for destination
      const marker = createMarker(place.geometry.location, 'destination');
      
      // Ensure input shows full address
      destinationInput.value = place.formatted_address || place.name;

      // Store geocoded location data
      window.destinationAddress = place.formatted_address || place.name;
      window.destinationLocation = {
        lat: place.geometry.location.lat(),
        lng: place.geometry.location.lng()
      };
    }
  });

  // Global methods to get selected locations
  window.getSelectedOrigin = () => window.originLocation;
  window.getSelectedDestination = () => window.destinationLocation;
}

// Attach to window for global access
window.initMapPointSelection = initMapPointSelection;

// Add event listener to ensure initialization
document.addEventListener('DOMContentLoaded', () => {
  // Check if Google Maps is loaded
  if (window.google && window.google.maps) {
    initMapPointSelection();
  } else {
    console.warn('Google Maps API not loaded. Waiting for initialization.');
  }
});
// The rest of the functions from the previous main.js implementation remain unchanged

/**
 * Set up event listeners for the application
 */
function setupEventListeners() {
  // Set up route form submission
  const findRouteBtn = document.querySelector('button[class*="find-safest-route"], button[class*="find_safest_route"], button.btn-primary');
  if (findRouteBtn) {
    findRouteBtn.addEventListener('click', function(e) {
      e.preventDefault();
      calculateRoutes();
    });
  }
  
  // Find the "Find Safest Route" button by text content
  const allButtons = document.querySelectorAll('button');
  allButtons.forEach(button => {
    if (button.textContent.trim().includes('Find Safest Route')) {
      button.addEventListener('click', function(e) {
        e.preventDefault();
        calculateRoutes();
      });
    }
  });
  
  // Set up origin and destination select buttons
  const originSelectBtns = document.querySelectorAll('button');
  let originSelectBtn = null;
  let destSelectBtn = null;
  
  // Find select buttons by their text content
  originSelectBtns.forEach(button => {
    if (button.textContent.trim() === 'Select') {
      if (!originSelectBtn) {
        originSelectBtn = button;
      } else if (!destSelectBtn) {
        destSelectBtn = button;
      }
    }
  });
  
  if (originSelectBtn) {
    originSelectBtn.addEventListener('click', function() {
      window.activeSelection = 'origin';
      showToast('Click on the map to select origin point', 'info');
      document.getElementById('map').classList.add('picking-point');
    });
  }
  
  if (destSelectBtn) {
    destSelectBtn.addEventListener('click', function() {
      window.activeSelection = 'destination';
      showToast('Click on the map to select destination point', 'info');
      document.getElementById('map').classList.add('picking-point');
    });
  }
  
  // Set up autocomplete for input fields
  const originInput = document.querySelector('input[placeholder="Enter starting point"]');
  const destinationInput = document.querySelector('input[placeholder="Enter destination"]');
  
  if (originInput && destinationInput && window.google && window.google.maps && window.google.maps.places) {
    const originAutocomplete = new google.maps.places.Autocomplete(originInput);
    const destinationAutocomplete = new google.maps.places.Autocomplete(destinationInput);
    
    // Prevent form submission when selecting a place with Enter key
    originInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') e.preventDefault();
    });
    
    destinationInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') e.preventDefault();
    });
  }
  
  // Set up tab switching
  const tabs = document.querySelectorAll('.nav-link');
  tabs.forEach(tab => {
    tab.addEventListener('click', function(e) {
      e.preventDefault();
      tabs.forEach(t => t.classList.remove('active'));
      this.classList.add('active');
      
      // Show corresponding tab content
      const targetId = this.getAttribute('data-bs-target');
      document.querySelectorAll('.tab-pane').forEach(pane => {
        pane.classList.remove('show', 'active');
      });
      
      document.querySelector(targetId).classList.add('show', 'active');
    });
  });
  
  // Set up route detail view when clicking on a route
  document.addEventListener('click', function(e) {
    if (e.target.classList.contains('view-route-details') || 
        e.target.closest('.view-route-details')) {
      const routeId = e.target.closest('.view-route-details').getAttribute('data-route-id');
      if (routeId) {
        showRouteDetails(routeId);
      }
    }
  });
}

/**
 * Calculate routes between origin and destination
 */
// Remove old setupMapPointSelection function
// Replace with the new implementation from the artifact above

// Update route calculation to use new methods
function calculateRoutes() {
  // Get addresses and locations
  const origin = window.originAddress || document.getElementById('origin-input').value;
  const destination = window.destinationAddress || document.getElementById('destination-input').value;
  const originLocation = window.originLocation;
  const destinationLocation = window.destinationLocation;
  
  // Validate inputs
  if (!origin && !originLocation) {
    showToast('Please enter an origin', 'error');
    return;
  }
  
  if (!destination && !destinationLocation) {
    showToast('Please enter a destination', 'error');
    return;
  }
  
  // Show loading state
  document.getElementById('route-results').innerHTML = '<div class="loading">Calculating safest routes...</div>';
  document.getElementById('route-details').innerHTML = '';
  
  // Clear existing routes
  clearRoutes();
  
  // Collect form data
  const formData = {
    origin,
    destination,
    originLat: originLocation?.lat,
    originLng: originLocation?.lng,
    destLat: destinationLocation?.lat,
    destLng: destinationLocation?.lng,
    tankerType: document.getElementById('tanker-type').value,
    hazmatClass: document.getElementById('hazmat-class').value,
    avoidHighways: document.getElementById('avoid-highways').checked,
    avoidTolls: document.getElementById('avoid-tolls').checked
  };
  
  // Send API request
  fetch('/api/calculate-routes', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(formData)
  })
  .then(response => response.json())
  .then(data => {
    if (!data.success) {
      throw new Error(data.message || 'Failed to calculate routes');
    }
    
    // Store routes
    window.currentRoutes = data.routes;
    
    // Display routes on map
    displayRoutes(data.routes);
    
    // Display route list
    displayRouteList(data.routes);
    
    // Show details for the safest route
    if (data.routes.length > 0) {
      showRouteDetails(data.routes[0].routeId);
    }
  })
  .catch(error => {
    console.error('Error:', error);
    showToast(error.message, 'error');
    document.getElementById('route-results').innerHTML = `
      <div class="alert alert-danger">
        Failed to calculate routes. 
        Error: ${error.message}
      </div>
    `;
  });
}

function displayRoutes(routes) {
  // Clear existing routes
  clearRoutes();
  
  // Check if Google Maps is available
  if (!window.google || !window.google.maps) {
    console.error('Google Maps API not loaded');
    return;
  }

  // Display each route as a polyline
  routes.forEach(route => {
    // Decode the polyline
    const path = window.google.maps.geometry.encoding.decodePath(route.polyline);
    
    // Create polyline
    const polyline = new window.google.maps.Polyline({
      path: path,
      strokeColor: route.color || '#3498db',
      strokeOpacity: route.isSafest ? 1.0 : 0.7,
      strokeWeight: route.isSafest ? 6 : 4,
      map: window.map,
      zIndex: route.isSafest ? 10 : 1
    });
    
    // Store route ID with the polyline
    polyline.routeId = route.routeId;
    
    // Add click listener
    polyline.addListener('click', function() {
      showRouteDetails(this.routeId);
    });
    
    // Add to the collection
    window.routePolylines.push(polyline);
  });
  
  // Fit map to show all routes
  if (routes.length > 0 && routes[0].bounds) {
    const bounds = new window.google.maps.LatLngBounds(
      new window.google.maps.LatLng(
        routes[0].bounds.southwest.lat,
        routes[0].bounds.southwest.lng
      ),
      new window.google.maps.LatLng(
        routes[0].bounds.northeast.lat,
        routes[0].bounds.northeast.lng
      )
    );
    window.map.fitBounds(bounds);
  }
  
  // Add origin and destination markers
  if (window.originLocation) {
    window.originMarker = createMarker(
      window.originLocation,
      window.map,
      'Origin',
      '<div class="marker-content origin-marker">Origin</div>'
    );
  }
  
  if (window.destinationLocation) {
    window.destinationMarker = createMarker(
      window.destinationLocation,
      window.map,
      'Destination',
      '<div class="marker-content destination-marker">Destination</div>'
    );
  }
}

/**
 * Display route list in the sidebar
 * @param {Array} routes - Array of route objects
 */
function displayRouteList(routes) {
  const container = document.getElementById('route-results');
  
  if (!container) return;
  
  let html = '<div class="route-list">';
  
  routes.forEach((route, index) => {
    const distanceKm = (route.distance / 1000).toFixed(2);
    const durationMin = Math.floor(route.duration / 60);
    
    html += `
      <div class="card route-card ${route.isSafest ? 'safest-route' : ''} mb-3">
        <div class="card-status-top bg-success"></div>
        <div class="card-body">
          <h3 class="card-title">
            ${route.isSafest ? '<span class="badge bg-success me-2">Safest</span>' : `<span class="badge bg-secondary me-2">Route ${index + 1}</span>`}
            <span>${route.summary || `Route ${index + 1}`}</span>
          </h3>
          <div class="route-metrics">
            <div class="route-metric">
              <i class="ti ti-ruler"></i>
              <span>${distanceKm} km</span>
            </div>
            <div class="route-metric">
              <i class="ti ti-clock"></i>
              <span>${durationMin} min</span>
            </div>
            <div class="route-metric">
              <i class="ti ti-shield"></i>
              <span>Safety: ${route.safetyScore.toFixed(2)}</span>
            </div>
          </div>
          <button class="btn btn-primary btn-sm mt-3 view-route-details" data-route-id="${route.routeId}">
            View Details
          </button>
        </div>
      </div>
    `;
  });
  
  html += '</div>';
  container.innerHTML = html;
}

/**
 * Show detailed metrics for a specific route
 * @param {string} routeId - Route identifier
 */
function showRouteDetails(routeId) {
  // Highlight the selected route on the map
  highlightRoute(routeId);
  
  // Find the route in the current routes
  const route = window.currentRoutes.find(r => r.routeId === routeId);
  
  if (!route) {
    console.error('Route not found:', routeId);
    return;
  }
  
  // Get the details container
  const container = document.getElementById('route-details');
  
  if (!container) return;
  
  // Show loading state
  container.innerHTML = '<div class="loading">Loading route details...</div>';
  
  // Fetch detailed metrics from the API
  fetch(`/api/route-metrics/${routeId}`)
    .then(response => response.json())
    .then(data => {
      if (!data.success) {
        throw new Error(data.message || 'Failed to fetch route details');
      }
      
      const metrics = data.metrics;
      
      // Display route details
      container.innerHTML = `
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">
              ${route.isSafest ? '<span class="badge bg-success me-2">Safest Route</span>' : ''}
              ${route.summary || 'Route Details'}
            </h3>
          </div>
          <div class="card-body">
            <div class="mb-4">
              <h4 class="mb-3">Route Justification</h4>
              <p>${route.justification}</p>
            </div>
            
            <h4 class="mb-3">Basic Metrics</h4>
            <div class="metrics-grid mb-4">
              <div class="metric-item">
                <div class="metric-title">Distance</div>
                <div class="metric-value">${metrics.basicMetrics.distance}</div>
              </div>
              <div class="metric-item">
                <div class="metric-title">Duration</div>
                <div class="metric-value">${metrics.basicMetrics.duration}</div>
              </div>
              <div class="metric-item">
                <div class="metric-title">Duration in Traffic</div>
                <div class="metric-value">${metrics.basicMetrics.trafficDuration}</div>
              </div>
              <div class="metric-item">
                <div class="metric-title">Fuel Consumption (est.)</div>
                <div class="metric-value">${metrics.basicMetrics.fuelConsumption}</div>
              </div>
              <div class="metric-item">
                <div class="metric-title">CO₂ Emissions (est.)</div>
                <div class="metric-value">${metrics.basicMetrics.co2Emissions}</div>
              </div>
              <div class="metric-item">
                <div class="metric-title">Average Speed</div>
                <div class="metric-value">${metrics.basicMetrics.averageSpeed}</div>
              </div>
            </div>
            
            <h4 class="mb-3">Safety Metrics</h4>
            <div class="safety-metrics mb-4">
              ${Object.entries(metrics.safetyPercentages).map(([key, value]) => {
                const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
                return `
                  <div class="safety-metric">
                    <div class="safety-label">${label}</div>
                    <div class="safety-bar">
                      <div class="safety-fill" style="width: ${value}%;"></div>
                    </div>
                  </div>
                `;
              }).join('')}
            </div>
            
            ${metrics.restrictions.hazmat.length > 0 ? `
              <h4 class="mb-3">Hazmat Restrictions</h4>
              <ul class="mb-4">
                ${metrics.restrictions.hazmat.map(r => `
                  <li><strong>${r.location}:</strong> ${r.description}</li>
                `).join('')}
              </ul>
            ` : ''}
            
            ${metrics.restrictions.speed.length > 0 ? `
              <h4 class="mb-3">Speed Restrictions</h4>
              <ul class="mb-4">
                ${metrics.restrictions.speed.map(r => `
                  <li><strong>${r.location}:</strong> ${r.limit}</li>
                `).join('')}
              </ul>
            ` : ''}
            
            ${metrics.restrictions.weight.length > 0 ? `
              <h4 class="mb-3">Weight Restrictions</h4>
              <ul class="mb-4">
                ${metrics.restrictions.weight.map(r => `
                  <li><strong>${r.location}:</strong> ${r.limit}</li>
                `).join('')}
              </ul>
            ` : ''}
          </div>
        </div>
      `;
    })
    .catch(error => {
      console.error('Error:', error);
      container.innerHTML = '<div class="alert alert-danger">Failed to load route details. Please try again.</div>';
    });
}

/**
 * Highlight a specific route on the map
 * @param {string} routeId - Route identifier
 */
function highlightRoute(routeId) {
  window.routePolylines.forEach(polyline => {
    const isSelected = polyline.routeId === routeId;
    const route = window.currentRoutes.find(r => r.routeId === polyline.routeId);
    
    polyline.setOptions({
      strokeOpacity: isSelected ? 1.0 : 0.5,
      strokeWeight: isSelected ? 6 : 4,
      zIndex: isSelected ? 10 : 1
    });
  });
}

/**
 * Clear all routes from the map
 */
function clearRoutes() {
  window.routePolylines.forEach(polyline => {
    polyline.setMap(null);
  });
  window.routePolylines = [];
}

/**
 * Load and display restricted zones on the map
 */
function loadRestrictedZones() {
  // In a real app, you would fetch this data from the server
  // For demo purposes, we'll add some example zones
  
  // Add some school zones
  const schoolZones = [
    { lat: 40.7128, lng: -74.0260, radius: 300 },
    { lat: 40.7328, lng: -74.0160, radius: 250 }
  ];
  
  schoolZones.forEach(zone => {
    new google.maps.Circle({
      strokeColor: '#FF0000',
      strokeOpacity: 0.8,
      strokeWeight: 2,
      fillColor: '#FF0000',
      fillOpacity: 0.1,
      map: window.map,
      center: { lat: zone.lat, lng: zone.lng },
      radius: zone.radius
    });
  });
  
  // Add residential areas
  const residentialAreas = [
    { lat: 40.7228, lng: -74.0060, radius: 500 },
    { lat: 40.7028, lng: -73.9760, radius: 600 }
  ];
  
  residentialAreas.forEach(area => {
    new google.maps.Circle({
      strokeColor: '#FFA500',
      strokeOpacity: 0.8,
      strokeWeight: 2,
      fillColor: '#FFA500',
      fillOpacity: 0.1,
      map: window.map,
      center: { lat: area.lat, lng: area.lng },
      radius: area.radius
    });
  });
}

/**
 * Show a toast notification
 * @param {string} message - Toast message
 * @param {string} type - Toast type (success, info, warning, error)
 */
function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <div class="toast-header">
      <strong class="me-auto">${type.charAt(0).toUpperCase() + type.slice(1)}</strong>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body">${message}</div>
  `;
  
  document.body.appendChild(toast);
  
  const bsToast = new bootstrap.Toast(toast);
  bsToast.show();
  
  toast.addEventListener('hidden.bs.toast', function() {
    document.body.removeChild(toast);
  });
}